import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity, ArrowDownToLine, ArrowLeftRight, ArrowRight, Bell, Box, Check, CheckCircle2,
  ChevronRight, CircleHelp, Clock3, Cloud, Copy, ExternalLink, Filter, Globe2, LayoutDashboard,
  LogIn, LogOut, MapPin, Menu, Package, PackageCheck, Plus, Radar, RefreshCw, Search,
  Settings2, ShieldCheck, Truck, X, Zap
} from 'lucide-react';
import { cloudEnabled, supabase } from './supabase';

const DEMO = [
  { id:'demo-1', tracking_number:'1Z999AA10123456784', carrier:'UPS', title:'Studio equipment', origin:'Austin, TX', destination:'Cincinnati, OH', status:'In transit', checkpoint:'Louisville, KY', updated:'Today, 10:42 AM', eta:'Oct 30, 2026', progress:68, slug:'ups', demo:true },
  { id:'demo-2', tracking_number:'9400111899223856928493', carrier:'USPS', title:'Priority parcel', origin:'Houston, TX', destination:'Dallas, TX', status:'Out for delivery', checkpoint:'Dallas, TX', updated:'Today, 9:18 AM', eta:'Oct 28, 2026', progress:88, slug:'usps', demo:true },
  { id:'demo-3', tracking_number:'JD0146000062810001', carrier:'DHL', title:'Express document', origin:'Memphis, TN', destination:'Austin, TX', status:'Info received', checkpoint:'Label created', updated:'Yesterday, 7:30 PM', eta:'Oct 31, 2026', progress:18, slug:'dhl', demo:true },
  { id:'demo-4', tracking_number:'6129999888888888888', carrier:'FedEx', title:'Smart device', origin:'Dallas, TX', destination:'Houston, TX', status:'Delivered', checkpoint:'Houston, TX', updated:'Oct 27, 3:06 PM', eta:'Delivered Oct 27', progress:100, slug:'fedex', demo:true },
];
const statusTone = (s='') => /deliver/i.test(s) ? 'green' : /exception|fail|expired|return/i.test(s) ? 'red' : /transit|pickup|out for/i.test(s) ? 'blue' : 'amber';
const iconFor = (s) => /deliver/i.test(s) ? CheckCircle2 : /transit|pickup/i.test(s) ? Truck : Package;
function normaliseTracking(data, fallback={}) {
  const d = data?.data || data || {};
  const checkpoints = d.checkpoints || [];
  const last = checkpoints[0] || {};
  const status = d.tag || d.subtag_message || d.subtag || d.status || fallback.status || 'Tracking created';
  return {
    ...fallback, tracking_number: d.tracking_number || fallback.tracking_number,
    carrier: d.slug || fallback.carrier || 'Detected carrier',
    status, checkpoint: [last.city, last.state, last.country_region_name].filter(Boolean).join(', ') || last.message || 'Awaiting first carrier scan',
    updated: last.checkpoint_time || d.updated_at || fallback.updated || 'Waiting for carrier update',
    eta: d.aftership_estimated_delivery_date?.estimated_delivery_date || d.courier_estimated_delivery_date?.estimated_delivery_date || fallback.eta || 'Not available yet',
    progress: /delivered/i.test(status) ? 100 : /out for delivery/i.test(status) ? 88 : /transit|pickup/i.test(status) ? 62 : /info received|pending/i.test(status) ? 18 : fallback.progress || 25,
    checkpoints, raw: d
  };
}
function App() {
  const [page,setPage] = useState('Overview');
  const [shipments,setShipments] = useState(() => {
    try { return JSON.parse(localStorage.getItem('nexus-shipments') || 'null') || DEMO; } catch { return DEMO; }
  });
  const [query,setQuery] = useState('');
  const [filter,setFilter] = useState('All');
  const [selected,setSelected] = useState(null);
  const [modal,setModal] = useState(false);
  const [form,setForm] = useState({tracking_number:'',carrier:'auto',title:''});
  const [busy,setBusy] = useState(false);
  const [message,setMessage] = useState('');
  const [user,setUser] = useState(null);
  const [authOpen,setAuthOpen] = useState(false);
  const [authForm,setAuthForm] = useState({email:'',password:''});
  const [mobileNav,setMobileNav] = useState(false);
  const [syncing,setSyncing] = useState(false);

  useEffect(() => { localStorage.setItem('nexus-shipments', JSON.stringify(shipments)); }, [shipments]);
  useEffect(() => {
    if (!cloudEnabled) return;
    supabase.auth.getSession().then(({data}) => setUser(data.session?.user || null));
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_event, session) => setUser(session?.user || null));
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!cloudEnabled || !user) return;
    (async () => {
      const {data,error} = await supabase.from('shipments').select('*').order('created_at',{ascending:false});
      if (!error && data) setShipments(data.map(row => ({...row, title:row.title || row.tracking_number, carrier:row.carrier || 'Unknown', status:row.status || 'Tracking created', progress:row.progress ?? 15})));
    })();
  }, [user]);

  const visible = useMemo(() => shipments.filter(s => {
    const q = query.toLowerCase();
    const matches = [s.tracking_number,s.carrier,s.title,s.origin,s.destination,s.status].some(v => String(v||'').toLowerCase().includes(q));
    return matches && (filter==='All' || (filter==='Active' ? !/deliver/i.test(s.status) : /deliver/i.test(s.status)));
  }), [shipments,query,filter]);
  const active = shipments.filter(s => !/deliver/i.test(s.status)).length;
  const delivered = shipments.filter(s => /deliver/i.test(s.status)).length;
  const selectedShipment = shipments.find(s => s.id === selected) || null;

  async function persistShipment(item) {
    if (cloudEnabled && user && !item.demo) {
      const payload = {
        user_id:user.id, tracking_number:item.tracking_number, carrier:item.carrier, title:item.title || '',
        status:item.status, checkpoint:item.checkpoint, eta:item.eta, progress:item.progress,
        provider_tracking_id:item.provider_tracking_id || null, raw_tracking:item.raw || null, updated_at:new Date().toISOString()
      };
      const {data,error} = await supabase.from('shipments').upsert(payload,{onConflict:'user_id,tracking_number'}).select().single();
      if (error) throw error;
      return {...item,...data};
    }
    return item;
  }
  async function addTracking(e) {
    e.preventDefault(); setBusy(true); setMessage('');
    try {
      const num = form.tracking_number.trim();
      if (!num) throw new Error('Enter a tracking number.');
      const body = { tracking_number:num, ...(form.carrier!=='auto' ? {slug:form.carrier} : {}) };
      const res = await fetch('/api/trackings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      const payload = await res.json().catch(()=>({}));
      if (!res.ok) throw new Error(payload.error || 'Could not create live tracking. Check your API setup.');
      const item = normaliseTracking(payload,{id:crypto.randomUUID(),tracking_number:num,carrier:form.carrier==='auto'?'Auto-detect':form.carrier,title:form.title.trim()||num,progress:15});
      item.id = item.id || crypto.randomUUID();
      item.provider_tracking_id = payload?.data?.id || payload?.id || null;
      item.demo = false;
      const saved = await persistShipment(item);
      setShipments(prev => [saved,...prev.filter(x => x.tracking_number!==num)]);
      setSelected(saved.id); setPage('Tracking'); setModal(false);
      setForm({tracking_number:'',carrier:'auto',title:''});
      setMessage('Tracking added. Status will update when the courier provider returns scan data.');
    } catch(err) {
      setMessage(err.message || 'Something went wrong.');
    } finally { setBusy(false); }
  }
  async function refreshShipment(s) {
    setBusy(true); setMessage('');
    try {
      if (s.demo) throw new Error('This is sample data. Add a real tracking number with an AfterShip API key to receive live carrier updates.');
      if (!s.provider_tracking_id) throw new Error('No provider tracking ID is saved. Add this tracking number again after configuring the tracking API.');
      const res = await fetch(`/api/trackings/${encodeURIComponent(s.provider_tracking_id)}`);
      const payload = await res.json().catch(()=>({}));
      if (!res.ok) throw new Error(payload.error || 'Unable to refresh this tracking.');
      const updated = {...s,...normaliseTracking(payload,s),raw:payload?.data || payload};
      const saved = await persistShipment(updated);
      setShipments(prev=>prev.map(x=>x.id===s.id? saved:x));
      setMessage('Tracking refreshed from provider.');
    } catch(err) { setMessage(err.message); }
    finally { setBusy(false); }
  }
  async function refreshAll() {
    setSyncing(true);
    for (const s of shipments.filter(x=>!x.demo && x.provider_tracking_id)) await refreshShipment(s);
    setSyncing(false);
  }
  async function authSubmit(e) {
    e.preventDefault(); setMessage('');
    if (!cloudEnabled) { setMessage('Cloud storage is not configured yet. Add Supabase settings from the setup guide.'); return; }
    const {email,password} = authForm;
    const result = user ? await supabase.auth.signOut() : await supabase.auth.signInWithPassword({email,password});
    if (result.error && !user) {
      const signUp = await supabase.auth.signUp({email,password});
      if (signUp.error) setMessage(signUp.error.message);
      else setMessage('Account created. If email confirmation is enabled, confirm your email and then sign in.');
    } else if (result.error) setMessage(result.error.message);
    else { setAuthOpen(false); setMessage(user ? 'Signed out.' : 'Signed in. Cloud shipments are loading.'); }
  }
  function openShipment(s) { setSelected(s.id); setPage('Tracking'); setMessage(''); }
  const nav = [{name:'Overview',icon:LayoutDashboard},{name:'Shipments',icon:Package},{name:'Tracking',icon:Radar},{name:'Analytics',icon:Activity}];

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav?'open':''}`}>
      <div className="brand"><div className="brand-mark"><Zap size={23}/></div><div><strong>NEXUS<span>LOGISTICS</span></strong><small>SHIPMENT INTELLIGENCE</small></div><button className="icon-btn mobile-close" onClick={()=>setMobileNav(false)}><X size={18}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map(({name,icon:Icon})=><button key={name} className={`nav-item ${page===name?'active':''}`} onClick={()=>{setPage(name);setMobileNav(false);setMessage('')}}><Icon size={18}/><span>{name}</span>{name==='Shipments'&&<span className="nav-count">{shipments.length}</span>}</button>)}</nav>
      <div className="side-bottom">
        <div className="api-card"><div className="api-icon"><ShieldCheck size={17}/></div><div><strong>{cloudEnabled?'Cloud configured':'Local mode'}</strong><p>{cloudEnabled?'Supabase settings detected':'Setup needed for sync'}</p></div><span className={`status-dot ${cloudEnabled?'green':''}`}/></div>
        <button className="nav-item" onClick={()=>setAuthOpen(true)}>{user?<LogOut size={18}/>:<LogIn size={18}/>}<span>{user?'Account / sign out':'Sign in / cloud sync'}</span></button>
        <div className="profile"><div className="avatar">{user?(user.email?.[0]||'U').toUpperCase():'N'}</div><div className="profile-text"><strong>{user?user.email:'NEXUS workspace'}</strong><small>{user?'Cloud account':'Personal dashboard'}</small></div><Settings2 size={17} className="muted-icon"/></div>
      </div>
    </aside>
    {mobileNav&&<button className="scrim" onClick={()=>setMobileNav(false)} aria-label="Close navigation"/>}
    <main className="main-content">
      <header className="topbar"><button className="icon-btn menu-btn" onClick={()=>setMobileNav(true)}><Menu size={20}/></button><div className="breadcrumb"><span>Workspace</span><ChevronRight size={14}/><strong>{page}</strong></div><div className="top-actions"><span className="environment"><i/> {cloudEnabled&&user?'CLOUD SYNC':'PERSONAL MODE'}</span><button className="icon-btn" title="Help / setup" onClick={()=>setPage('Setup')}><CircleHelp size={18}/></button><button className="icon-btn" title="Account" onClick={()=>setAuthOpen(true)}><Bell size={18}/></button><button className="primary-btn small" onClick={()=>{setModal(true);setMessage('')}}><Plus size={16}/> Add tracking</button></div></header>
      <div className="page-body">
        {message&&<div className="notice"><span>{message}</span><button onClick={()=>setMessage('')}><X size={15}/></button></div>}
        {page==='Overview'&&<Overview shipments={shipments} active={active} delivered={delivered} onAdd={()=>setModal(true)} onSelect={openShipment} onRefresh={refreshAll} syncing={syncing} onPage={setPage}/>}
        {page==='Shipments'&&<section><div className="page-heading"><div><div className="eyebrow">SHIPMENT MANAGEMENT</div><h1>All shipments<span>.</span></h1><p>Search and manage packages from multiple carriers.</p></div><button className="primary-btn" onClick={()=>setModal(true)}><Plus size={17}/> Add shipment</button></div><ShipmentTable rows={visible} query={query} setQuery={setQuery} filter={filter} setFilter={setFilter} onSelect={openShipment}/></section>}
        {page==='Tracking'&&<section><div className="page-heading"><div><div className="eyebrow">LIVE TRACKING</div><h1>Shipment details<span>.</span></h1><p>Provider updates appear here when the API is configured.</p></div>{selectedShipment&&<button className="secondary-btn" disabled={busy} onClick={()=>refreshShipment(selectedShipment)}><RefreshCw size={16}/> Refresh status</button>}</div>{selectedShipment?<TrackingDetails shipment={selectedShipment} onRefresh={()=>refreshShipment(selectedShipment)} busy={busy}/>:<div className="empty-state"><Radar size={34}/><h3>Select a shipment</h3><p>Open a shipment from the registry to view its tracking timeline.</p><button className="primary-btn" onClick={()=>setPage('Shipments')}>Browse shipments</button></div>}</section>}
        {page==='Analytics'&&<Analytics shipments={shipments}/>}
        {page==='Setup'&&<Setup cloudEnabled={cloudEnabled} user={user}/>}
      </div>
      <footer className="footer"><span><span className="live-dot"/> NEXUS SYSTEM READY</span><span>v1.0.0 <b>•</b> {cloudEnabled?'CLOUD CONFIGURED':'LOCAL-FIRST BUILD'}</span></footer>
    </main>
    {modal&&<div className="modal-backdrop" onClick={()=>setModal(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="modal-header"><div><div className="eyebrow">NEW SHIPMENT</div><h2>Add tracking</h2><p>Connect a carrier tracking number.</p></div><button className="icon-btn" onClick={()=>setModal(false)}><X size={19}/></button></div><form onSubmit={addTracking}><label>Tracking number <span>*</span><input autoFocus value={form.tracking_number} onChange={e=>setForm({...form,tracking_number:e.target.value})} placeholder="Enter courier tracking number" required/></label><label>Courier<select value={form.carrier} onChange={e=>setForm({...form,carrier:e.target.value})}><option value="auto">Auto-detect carrier</option><option value="ups">UPS</option><option value="usps">USPS</option><option value="fedex">FedEx</option><option value="dhl">DHL</option><option value="royal-mail">Royal Mail</option><option value="aramex">Aramex</option><option value="china-post">China Post</option><option value="canada-post">Canada Post</option></select></label><label>Package label <small>(optional)</small><input value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Shoes, laptop, documents"/></label><div className="provider-note"><Globe2 size={17}/><span>Carrier auto-detection and real scan updates require a configured tracking API key.</span></div><div className="modal-actions"><button type="button" className="secondary-btn" onClick={()=>setModal(false)}>Cancel</button><button type="submit" className="primary-btn" disabled={busy}>{busy?<RefreshCw className="spin" size={16}/>:<Radar size={16}/>} {busy?'Connecting…':'Connect tracking'}</button></div></form></div></div>}
    {authOpen&&<div className="modal-backdrop" onClick={()=>setAuthOpen(false)}><div className="modal auth-modal" onClick={e=>e.stopPropagation()}><div className="modal-header"><div><div className="eyebrow">YOUR ACCOUNT</div><h2>{user?'Cloud account':'Sign in / create account'}</h2><p>{user?'Sign out of this account.':'Cloud sync keeps shipments across your devices.'}</p></div><button className="icon-btn" onClick={()=>setAuthOpen(false)}><X size={19}/></button></div>{user?<button className="primary-btn full" onClick={authSubmit}><LogOut size={16}/> Sign out</button>:<form onSubmit={authSubmit}><label>Email<input type="email" required value={authForm.email} onChange={e=>setAuthForm({...authForm,email:e.target.value})} placeholder="you@example.com"/></label><label>Password<input type="password" minLength="6" required value={authForm.password} onChange={e=>setAuthForm({...authForm,password:e.target.value})} placeholder="At least 6 characters"/></label><button className="primary-btn full" type="submit"><LogIn size={16}/> Continue with email</button><p className="form-footnote">Creates an account if one doesn't exist. Email confirmation may be required.</p></form>}</div></div>}
  </div>;
}

function Overview({shipments,active,delivered,onAdd,onSelect,onRefresh,syncing,onPage}) {
  const [period,setPeriod] = useState('7 days');
  const bars = [42,64,53,82,70,48,66];
  return <section>
    <div className="hero-row"><div><div className="eyebrow"><span className="live-dot"/> DELIVERY OPERATIONS / OVERVIEW</div><h1>Command center<span>.</span></h1><p className="subtitle">Your shipments. Every carrier. One clear view.</p></div><div className="hero-actions"><button className="secondary-btn" onClick={onRefresh} disabled={syncing}><RefreshCw size={16} className={syncing?'spin':''}/>{syncing?'Syncing…':'Sync tracking'}</button><button className="primary-btn" onClick={onAdd}><Plus size={17}/> Add shipment</button></div></div>
    <div className="stat-grid"><Stat icon={Package} label="TOTAL SHIPMENTS" value={shipments.length.toLocaleString()} note="Saved in workspace" tone="cyan"/><Stat icon={Truck} label="IN PROGRESS" value={active.toLocaleString()} note="Not yet delivered" tone="blue"/><Stat icon={PackageCheck} label="DELIVERED" value={delivered.toLocaleString()} note="Completed shipments" tone="green"/><Stat icon={Activity} label="CARRIERS" value={new Set(shipments.map(s=>s.carrier).filter(Boolean)).size.toString()} note="Across your registry" tone="purple"/></div>
    <div className="dashboard-grid"><div className="panel activity-panel"><div className="panel-heading"><div><h3>Shipment activity</h3><p>Illustrative volume trend</p></div><select value={period} onChange={e=>setPeriod(e.target.value)}><option>7 days</option><option>30 days</option><option>90 days</option></select></div><div className="chart"><div className="chart-y"><span>100</span><span>75</span><span>50</span><span>25</span><span>0</span></div><div className="chart-main"><div className="chart-gridlines"><i/><i/><i/><i/><i/></div><div className="bars">{bars.map((v,i)=><div className="bar-wrap" key={i}><div className="bar" style={{height:`${Math.min(100,v+(period==='30 days'?12:period==='90 days'?20:0))}%`}} title={`${v} sample shipments`}/><span>{['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][i]}</span></div>)}</div></div></div><div className="chart-caption"><span><i className="legend-dot"/> Sample shipment volume</span><span>Illustrative data · not live analytics</span></div></div>
      <div className="panel status-panel"><div className="panel-heading"><div><h3>Shipment status</h3><p>Current saved packages</p></div><button className="text-btn" onClick={()=>onPage('Shipments')}>View all <ArrowRight size={14}/></button></div><div className="status-donut-wrap"><div className="donut" style={{'--done':`${shipments.length?delivered/shipments.length*100:0}%`}}><div><strong>{shipments.length}</strong><span>shipments</span></div></div><div className="status-legend"><div><i className="green-bg"/><span>Delivered</span><strong>{delivered}</strong></div><div><i className="blue-bg"/><span>In progress</span><strong>{active}</strong></div></div></div><div className="status-foot"><ShieldCheck size={15}/> Status comes from saved records or provider scans.</div></div></div>
    <div className="panel recent-panel"><div className="panel-heading"><div><h3>Recent shipments</h3><p>Latest packages in your workspace</p></div><button className="text-btn" onClick={()=>onPage('Shipments')}>All shipments <ArrowRight size={14}/></button></div><ShipmentTable rows={shipments.slice(0,4)} compact onSelect={onSelect}/></div>
  </section>;
}
function Stat({icon:Icon,label,value,note,tone}) { return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={19}/></div><span className="stat-label">{label}</span><strong className="stat-value">{value}</strong><span className="stat-note">{note}</span><div className={`stat-accent ${tone}`}/></div>; }
function ShipmentTable({rows,query='',setQuery=()=>{},filter='All',setFilter=()=>{},onSelect,compact=false}) {
 return <div className="table-wrap">{!compact&&<div className="table-tools"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search tracking, carrier, destination…"/>{query&&<button onClick={()=>setQuery('')}><X size={14}/></button>}</div><div className="filter-box"><Filter size={16}/><select value={filter} onChange={e=>setFilter(e.target.value)}><option>All</option><option>Active</option><option>Delivered</option></select></div></div>}<div className="table-scroll"><table><thead><tr><th>SHIPMENT / TRACKING</th><th>CARRIER</th><th>DESTINATION</th><th>STATUS</th><th>LAST UPDATE</th><th></th></tr></thead><tbody>{rows.map(s=>{const Icon=IconForStatus(s.status);return <tr key={s.id||s.tracking_number} onClick={()=>onSelect?.(s)} tabIndex="0" onKeyDown={e=>e.key==='Enter'&&onSelect?.(s)}><td><div className="shipment-cell"><div className="mini-package"><Package size={17}/></div><div><strong>{s.title||s.tracking_number}</strong><span>{s.tracking_number}</span></div></div></td><td><span className="carrier-name">{String(s.carrier||'Unknown').toUpperCase()}</span></td><td><div className="destination-cell"><MapPin size={14}/><span>{s.destination||s.checkpoint||'Awaiting scan'}</span></div></td><td><span className={`pill ${statusTone(s.status)}`}><i/>{s.status||'Pending'}</span></td><td><span className="last-update">{s.updated||'—'}</span></td><td><button className="row-arrow" aria-label="Open shipment"><ChevronRight size={17}/></button></td></tr>})}{rows.length===0&&<tr><td colSpan="6"><div className="table-empty"><Package size={24}/><strong>No shipments found</strong><span>Try another search or add a tracking number.</span></div></td></tr>}</tbody></table></div></div>;
}
function IconForStatus(status='') { return /deliver/i.test(status)?CheckCircle2:/transit|out for/i.test(status)?Truck:Package; }
function TrackingDetails({shipment:s,onRefresh,busy}) {
 const events = s.checkpoints?.length ? s.checkpoints : [
  {checkpoint_time:s.updated,message:s.checkpoint || 'Last known carrier update',tag:s.status},
  {checkpoint_time:'When shipment was registered',message:'Tracking added to NEXUS',tag:'Info'}
 ];
 return <div className="tracking-layout"><div className="panel tracking-main"><div className="tracking-top"><div className="big-package"><Package size={26}/></div><div className="tracking-title"><span className="eyebrow">TRACKING NUMBER</span><h2>{s.tracking_number}</h2><p>{s.title||'Package'} · {String(s.carrier||'Unknown').toUpperCase()}</p></div><button className="icon-btn" title="Copy tracking number" onClick={()=>navigator.clipboard?.writeText(s.tracking_number)}><Copy size={17}/></button></div><div className="tracking-status"><div><span className="field-label">CURRENT STATUS</span><div className={`status-large ${statusTone(s.status)}`}>{s.status}</div></div><div><span className="field-label">ESTIMATED DELIVERY</span><strong>{s.eta||'Awaiting carrier estimate'}</strong></div></div><div className="progress-section"><div className="progress-label"><span>Journey progress</span><strong>{s.progress??15}%</strong></div><div className="progress-track"><i style={{width:`${s.progress??15}%`}}/></div><div className="route-labels"><span>{s.origin||'Origin not available'}</span><ArrowRight size={15}/><span>{s.destination||'Destination not available'}</span></div></div><div className="route-visual"><div className="route-line"/><div className="route-point start"><i/></div><div className="route-point current"><Truck size={16}/></div><div className="route-point end"><MapPin size={17}/></div><div className="route-captions"><span><strong>Origin</strong>{s.origin||'Not supplied'}</span><span><strong>Last scan</strong>{s.checkpoint||'Awaiting scan'}</span><span><strong>Destination</strong>{s.destination||'Not supplied'}</span></div></div><div className="timeline-heading"><h3>Tracking history</h3><span>{s.checkpoints?.length||1} events shown</span></div><div className="timeline">{events.slice(0,12).map((ev,i)=><div className="timeline-event" key={i}><div className={`timeline-icon ${i===0?'current':''}`}><i/></div><div><strong>{ev.message||ev.subtag_message||ev.tag||'Carrier event'}</strong><p>{[ev.city,ev.state,ev.country_region_name,ev.location].filter(Boolean).join(', ')||'Location not provided by carrier'}</p><span>{ev.checkpoint_time||ev.created_at||'Time not provided'}</span></div></div>)}</div><div className="tracking-bottom"><span><Cloud size={15}/> {s.demo?'Sample record':'Provider-connected record'}</span><button className="secondary-btn" disabled={busy} onClick={onRefresh}><RefreshCw size={15} className={busy?'spin':''}/> Refresh data</button></div></div><aside className="tracking-aside"><div className="panel aside-card"><div className="aside-heading"><ShieldCheck size={18}/><h3>Tracking integrity</h3></div><p>{s.demo?'This is an example record. It does not contain live carrier events.':'Tracking data is returned by the configured provider. Delivery times are estimates.'}</p><div className="aside-divider"/><div className="aside-info"><span>Carrier</span><strong>{String(s.carrier||'Unknown').toUpperCase()}</strong></div><div className="aside-info"><span>Last updated</span><strong>{s.updated||'—'}</strong></div><div className="aside-info"><span>Reference</span><strong>{s.provider_tracking_id?'Provider linked':'Not linked'}</strong></div></div><div className="panel aside-card tip-card"><div className="tip-icon"><Zap size={18}/></div><h3>Need a fresh scan?</h3><p>Refresh to request the latest status from the tracking provider. Updates depend on carrier availability.</p><button className="secondary-btn full" disabled={busy} onClick={onRefresh}><RefreshCw size={15}/> Refresh tracking</button></div></aside></div>;
}
function Analytics({shipments}) {
 const delivered=shipments.filter(s=>/deliver/i.test(s.status)).length;
 const counts=['In transit','Out for delivery','Info received','Delivered','Exception'].map(status=>({status,count:shipments.filter(s=>String(s.status).toLowerCase().includes(status.toLowerCase())).length}));
 return <section><div className="page-heading"><div><div className="eyebrow">OPERATIONAL INTELLIGENCE</div><h1>Analytics<span>.</span></h1><p>Insights based on the shipment records currently saved.</p></div></div><div className="stat-grid"><Stat icon={Package} label="RECORDS" value={shipments.length} note="Current workspace" tone="cyan"/><Stat icon={PackageCheck} label="DELIVERED" value={delivered} note="Marked delivered" tone="green"/><Stat icon={Activity} label="DELIVERY RATE" value={`${shipments.length?Math.round(delivered/shipments.length*100):0}%`} note="Based on saved statuses" tone="purple"/><Stat icon={Clock3} label="LIVE FEED" value="—" note="Provider setup required" tone="blue"/></div><div className="panel analytics-panel"><div className="panel-heading"><div><h3>Status breakdown</h3><p>Calculated from your saved records</p></div></div>{counts.map(c=><div className="metric-row" key={c.status}><span>{c.status}</span><div className="metric-track"><i style={{width:`${shipments.length?c.count/shipments.length*100:0}%`}}/></div><strong>{c.count}</strong></div>)}<p className="form-footnote">Analytics will become meaningful once you add your own shipments. Historical data is not invented.</p></div></section>;
}
function Setup({cloudEnabled,user}) {
 return <section><div className="page-heading"><div><div className="eyebrow">DEPLOYMENT & INTEGRATIONS</div><h1>Setup center<span>.</span></h1><p>What is working now, and what is needed to go live.</p></div></div><div className="setup-grid"><div className="panel setup-card"><div className="setup-number">01</div><div className="setup-card-title"><DatabaseIcon/><h3>Persistent cloud storage</h3></div><p>Supabase stores shipment records across devices and supports account sign-in.</p><span className={`pill ${cloudEnabled?'green':'amber'}`}><i/>{cloudEnabled?'Environment detected':'Credentials required'}</span><ol><li>Create a Supabase project.</li><li>Run <code>supabase/schema.sql</code> in SQL Editor.</li><li>Copy project URL and publishable key into <code>.env</code>.</li><li>Sign in from NEXUS to enable account-scoped records.</li></ol></div><div className="panel setup-card"><div className="setup-number">02</div><div className="setup-card-title"><Globe2 size={20}/><h3>Multi-carrier live tracking</h3></div><p>Server-side AfterShip Tracking API adapter; carrier detection can be automatic or selected manually.</p><span className="pill amber"><i/>API key required</span><ol><li>Create an AfterShip Tracking account and confirm API access on your plan.</li><li>Set <code>AFTERSHIP_API_KEY</code> in server environment.</li><li>Add a real tracking number to create provider tracking.</li><li>Optionally configure AfterShip webhooks for faster updates.</li></ol><a href="https://www.aftership.com/docs/tracking/quickstart/api-quick-start" target="_blank" rel="noreferrer">Official API quick start <ExternalLink size={13}/></a></div><div className="panel setup-card"><div className="setup-number">03</div><div className="setup-card-title"><ShieldCheck size={20}/><h3>Security & production</h3></div><p>Keep API secrets on the server and restrict each user's shipment rows.</p><span className="pill amber"><i/>Review before launch</span><ol><li>Keep <code>.env</code> out of Git.</li><li>Confirm Supabase Row Level Security policies.</li><li>Deploy web frontend and Node server to a hosting provider.</li><li>Use HTTPS, backups, rate limits and email verification.</li></ol></div><div className="panel setup-card"><div className="setup-number">04</div><div className="setup-card-title"><RefreshCw size={20}/><h3>Automated updates</h3></div><p>The included refresh action requests the latest provider data. Automatic refresh and push notifications need additional deployment setup.</p><span className="pill amber"><i/>Optional next step</span><ol><li>Configure provider webhook URL on a public HTTPS server.</li><li>Verify webhook HMAC signatures.</li><li>Persist incoming events and update shipment records.</li><li>Add scheduled refresh or email/push notifications.</li></ol></div></div><div className="panel readiness"><div className="readiness-icon"><CheckCircle2 size={20}/></div><div><h3>Current build status</h3><p>Responsive UI, local browser persistence, shipment search/filtering, account flow, Supabase data layer, and an AfterShip server adapter are included in this project. Live multi-device sync requires Supabase credentials; real carrier updates require a supported provider account/API key. No app has been deployed yet.</p></div></div></section>;
}
function DatabaseIcon(){return <Cloud size={20}/>;}
export default App;
