# NEXUS Logistics — multi-carrier tracking starter

A responsive React/Vite web app designed for mobile and desktop. Includes a Node/Express server-side adapter for AfterShip Tracking API and optional Supabase account-based cloud persistence.

## Included now

- Responsive futuristic dark/neon dashboard, shipment list, search and filters.
- Shipment details, event timeline, status summaries, analytics.
- Add tracking form with courier auto-detection or a courier slug.
- Express endpoints that call AfterShip without exposing the API key in the browser.
- Local browser storage as an offline/personal fallback.
- Supabase database schema with row-level security and email/password sign-in flow.
- Clear UI notices for missing credentials and sample records.

## Important boundaries

- The four preloaded shipments are clearly sample records; they are not live tracking data.
- Local browser storage works without accounts but is only stored in that browser/device.
- Cross-device persistent storage requires a Supabase project, the SQL schema applied, and environment variables configured.
- Live multi-carrier tracking requires an AfterShip Tracking account/plan with API access and a server-side API key. Some carriers require extra fields or may not be supported by the selected provider/account.
- The API adapter supports creating a tracking and refreshing it by provider tracking ID. Automatic updates/webhooks, push notifications, map/GPS display, and scheduled polling are not enabled in this starter.
- This is source code, not a deployed public app. You must run it locally or deploy it to hosting.

## Requirements

Node.js 20+ recommended, npm, a browser.

## Run locally

1. Unzip the project and open a terminal in the project folder.
2. Install packages:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env`.
4. For a local UI preview, no credentials are required. Run:

   ```bash
   npm run dev
   ```

   Vite runs at `http://localhost:5173`; the API server runs at `http://localhost:8787`.

5. To enable live tracking, set `AFTERSHIP_API_KEY` in `.env`, restart the server, and add a real tracking number from a supported carrier. Keep this key server-side only.

## Enable cloud storage

1. Create a project at https://supabase.com.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Copy the Project URL and publishable key from the Supabase Connect panel into `.env`:

   ```dotenv
   VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
   ```

4. Add `AFTERSHIP_API_KEY` for live tracking.
5. Restart the app and server. Use “Sign in / cloud sync” to create an account or sign in.
6. Verify email confirmation settings in Supabase Auth. Keep RLS enabled. Never place a Supabase service-role key in frontend variables.

## AfterShip API setup

- Official quick start: https://www.aftership.com/docs/tracking/quickstart/api-quick-start
- Create an API key in your AfterShip Tracking account settings.
- API key is read by the server as `AFTERSHIP_API_KEY`; it is never sent to browser JavaScript.
- The server uses `https://api.aftership.com/tracking/2026-07`.
- API access depends on the AfterShip Tracking plan; check current plan and carrier coverage before relying on it.
- For more frequent updates, configure a public HTTPS webhook endpoint and verify `aftership-hmac-sha256` before accepting events. The webhook receiver is not implemented in this starter.

## Production deployment checklist

- Deploy the frontend and Node server, or serve the built `dist` directory from the server (`NODE_ENV=production`).
- Configure environment variables in the hosting dashboard, not in source control.
- Use HTTPS and set `APP_ORIGIN` to your frontend origin.
- Configure Supabase email verification, redirect URLs, RLS and backups.
- Add request rate limiting, webhook signature validation, monitoring, retry/backoff, and automated tests.
- Review privacy policy and retention rules for tracking numbers and any shipment data.
- Build a PWA manifest/service worker or wrap the web app if you require a home-screen install experience; this starter is responsive but is not yet packaged as a native iOS/Android app.

## Suggested next milestone

Add verified AfterShip webhook handling, automatic scheduled refresh, map display from provider checkpoint coordinates, and email/push alerts.
