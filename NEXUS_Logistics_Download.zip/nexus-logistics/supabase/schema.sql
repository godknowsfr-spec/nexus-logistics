-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.shipments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tracking_number text not null,
  carrier text not null default 'Unknown',
  title text not null default '',
  status text not null default 'Tracking created',
  checkpoint text,
  eta text,
  progress integer not null default 15 check (progress between 0 and 100),
  provider_tracking_id text,
  raw_tracking jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, tracking_number)
);

alter table public.shipments enable row level security;

drop policy if exists "Users can read their own shipments" on public.shipments;
create policy "Users can read their own shipments"
on public.shipments for select to authenticated
using (auth.uid() = user_id);

drop policy if exists "Users can create their own shipments" on public.shipments;
create policy "Users can create their own shipments"
on public.shipments for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Users can update their own shipments" on public.shipments;
create policy "Users can update their own shipments"
on public.shipments for update to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own shipments" on public.shipments;
create policy "Users can delete their own shipments"
on public.shipments for delete to authenticated
using (auth.uid() = user_id);

create index if not exists shipments_user_updated_idx
on public.shipments(user_id, updated_at desc);
