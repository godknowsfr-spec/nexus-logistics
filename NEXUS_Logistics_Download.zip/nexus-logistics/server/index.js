import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const PORT = Number(process.env.PORT || 8787);
const AFTERSHIP_BASE = 'https://api.aftership.com/tracking/2026-07';
app.use(cors({ origin: process.env.APP_ORIGIN || true }));
app.use(express.json({ limit: '100kb' }));

function apiKey() { return process.env.AFTERSHIP_API_KEY; }
async function aftership(pathname, options={}) {
  if (!apiKey()) {
    const error = new Error('Live tracking is not configured. Set AFTERSHIP_API_KEY on the server. Local demo records still work.');
    error.status = 503; throw error;
  }
  const response = await fetch(`${AFTERSHIP_BASE}${pathname}`, {
    ...options,
    headers: { 'as-api-key': apiKey(), 'Content-Type': 'application/json', ...(options.headers||{}) }
  });
  const payload = await response.json().catch(()=>({}));
  if (!response.ok) {
    const error = new Error(payload?.meta?.message || payload?.message || `Tracking provider returned HTTP ${response.status}`);
    error.status = response.status; throw error;
  }
  return payload;
}
app.get('/api/health', (_req,res)=>res.json({ok:true, providerConfigured:Boolean(apiKey())}));
app.post('/api/trackings', async (req,res) => {
  try {
    const tracking_number = String(req.body?.tracking_number || '').trim();
    if (!tracking_number || tracking_number.length > 160) return res.status(400).json({error:'A valid tracking number is required.'});
    const body = { tracking_number };
    if (req.body?.slug) body.slug = String(req.body.slug).trim().toLowerCase();
    const result = await aftership('/trackings', { method:'POST', body:JSON.stringify(body) });
    res.status(201).json(result);
  } catch (e) { res.status(e.status || 502).json({error:e.message || 'Tracking provider request failed.'}); }
});
app.get('/api/trackings/:id', async (req,res) => {
  try {
    if (!/^[a-zA-Z0-9_-]{8,100}$/.test(req.params.id)) return res.status(400).json({error:'Invalid provider tracking ID.'});
    const result = await aftership(`/trackings/${encodeURIComponent(req.params.id)}`);
    res.json(result);
  } catch (e) { res.status(e.status || 502).json({error:e.message || 'Tracking provider request failed.'}); }
});

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dist = path.resolve(__dirname,'../dist');
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(dist));
  app.get('/{*splat}',(_req,res)=>res.sendFile(path.join(dist,'index.html')));
}
app.listen(PORT,()=>console.log(`NEXUS API listening on http://localhost:${PORT}; AfterShip ${apiKey()?'configured':'not configured'}`));
